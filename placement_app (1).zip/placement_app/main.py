import streamlit as st
import sqlite3
import pandas as pd

# Connect to database
conn = sqlite3.connect("placement.db")
cursor = conn.cursor()

# Title
st.title("📊 Placement Eligibility Streamlit Application")

# Sidebar filters
st.sidebar.header("Eligibility Criteria")
min_problems_solved = st.sidebar.slider("Minimum Problems Solved", 0, 100, 50)
min_soft_skills_score = st.sidebar.slider("Minimum Soft Skills Avg Score", 0, 100, 75)

# SQL to fetch eligible students
query = f"""
SELECT s.student_id, s.name, s.age, s.gender, s.email, s.course_batch, s.city,
       p.problems_solved, ss.communication, ss.teamwork, ss.presentation,
       ss.leadership, ss.critical_thinking, ss.interpersonal_skills,
       pl.placement_status, pl.mock_interview_score
FROM Students s
JOIN Programming p ON s.student_id = p.student_id
JOIN SoftSkills ss ON s.student_id = ss.student_id
JOIN Placements pl ON s.student_id = pl.student_id
"""

df = pd.read_sql_query(query, conn)

# Calculate soft skills average
soft_skill_cols = ['communication', 'teamwork', 'presentation', 'leadership', 'critical_thinking', 'interpersonal_skills']
df["soft_skills_avg"] = df[soft_skill_cols].mean(axis=1)

# Filter based on criteria
filtered_df = df[(df["problems_solved"] >= min_problems_solved) & (df["soft_skills_avg"] >= min_soft_skills_score)]

# Display results
st.subheader("🎓 Eligible Students")
st.write(f"Showing students who solved at least {min_problems_solved} problems and have a soft skills avg of {min_soft_skills_score} or more.")
st.dataframe(filtered_df.reset_index(drop=True))
